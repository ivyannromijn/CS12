
// JavaScript source code



// given data
const options = {
    Jollibee: ["Jolly Spaghetti", "1 pc Chicken Joy", "Peach Mango Pie", "Aloha Yum Burger", "Palabok"],
    Mcdonalds: ["Hotcakes", "Cheesy Burger Mcdo", "Quarter Pounder", "Crispy Chicken Fillet", "McSpaghetti"],
    Chowking: ["Pork Chop Lauriat", "Chicken Lauriat", "Sweet and Sour Pork", "Pork Chao Fan", "Wantom Mami"]
}



// Random resto
let fastfood = Object.keys(options)[Math.floor(Math.random() * Object.keys(options).length)];
console.log(fastfood);

//random menu
var foodchoice = options[fastfood];
var randomfood = Math.floor(Math.random() * (foodchoice.length));
var menu = foodchoice[randomfood];
console.log(menu);


// for buttons
function fastfoodDisplay() {
    document.getElementById("results1").innerHTML = (fastfood);
}


function menuDisplay() {
    document.getElementById("results2").innerHTML = (menu);
}

