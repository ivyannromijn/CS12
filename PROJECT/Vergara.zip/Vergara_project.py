
from time import sleep


#print main menu
def printmenu():
	print("======= MAIN MENU =======")
	print("[1] Enter new diary entry")
	print("[2] View entry")
	print("[3] Edit Entry")
	print("[4] Save Entry")
	print("[5] Change password")
	print("[6] Instructions")
	print("[7] exit")





#mainmenu:
def menu():
	printmenu()
		
	choice=int(input("Option:"))
	

	while (True):
		if choice==1:
			newEntry()
			goMainorE()
			break
		elif choice==2:
			viewEntry()
			goMainorE()
			break
		elif choice==3:
			editEntry()
			goMainorE()
			break
		elif choice==4:
			saveEntry()
			goMainorE()
			break
		elif choice==5:
			changepassmenu()
			break
		elif choice==6:
			instructions()
			print()
			print()
			goMainorE()
			break
		elif choice==7:
			print("======= SEE YOU NEXT TIME <3 =======")
			quit()
			break
		else:
			print("Invalid choice, please try again")





#menu for changing passwords
def changepassmenu():
	while(True):
		print("Are you sure you want to change password")
		print("[1] Yes")
		print("[2] No")
	
		passmenu=int(input("Enter:"))
		if passmenu==1:
			changepass()
	
		elif passmenu==2:
			print("back to main")
			menu()
		else:
			print("invalid choice, try again")
			


#function for changing password
def changepass():
	with open("password.txt",'r') as file:
		passwords = file.readlines() 
	print ("Your current pass is: " + passwords[7])
	newpass=input("Enter new pin:") + '\n'
	passwords[7]=(newpass)

	with open("password.txt", 'w') as file:
		file.writelines( passwords )

	print("Password successfully changed.")
	goMainorE()


#menu for going back to main menu or exit
def goMainorE():
	def MainorE_menu():       
		print("[1] MAIN MENU")
		print("[2] Exit")
		choice_1=int(input("Option:"))
		return choice_1

	
	while True:          
		choice_1=MainorE_menu()    
		
		
		if choice_1==1:     
			menu()
		elif choice_1==2:
			print("Closing diary..")
			sleep(2)
			print("See you again soon...")
			exit()
			break
		else:
			print("Invalid Option") 


#decrypt the message
def decrypt(message, shift):
        nDecryptedMessage = ""
        decryptedMessage = ""
        cap = 0
        for ch in message.lower(): 
            if ch.isalpha():
                ch = ord(ch) 
                ch -= int(shift) 
                if ch < ord("a"): 
                    while ch < ord("a"): 
                        ch += 26 
                    decryptedMessage += chr(ch) 
                else:
                    decryptedMessage += chr(ch) 
            else:
                decryptedMessage += ch 
        for letter in decryptedMessage: 
            cap += 1 
            if cap == 1: 
                nDecryptedMessage += letter.upper() 
            else: 
                nDecryptedMessage += letter.lower() 
        return nDecryptedMessage 


#encrypt the message
def encrypt(message, shift):
        nEncryptedMessage = "" 
        encryptedMessage = "" 
        cap = 0 
        for ch in message.lower(): 
            if ch.isalpha(): 
                ch = ord(ch) 
                ch += int(shift) 
                if ch > ord("z"): 
                    while ch > ord("z"):
                        ch -= 26 
                    encryptedMessage += chr(ch) 
                else:
                    encryptedMessage += chr(ch) 
            else:
                encryptedMessage += ch 
        for letter in encryptedMessage: 
            cap += 1 
            if cap == 1: 
                nEncryptedMessage += letter.upper() 
            else: 
                nEncryptedMessage += letter.lower() 
        return nEncryptedMessage 


def newEntry():
	FileName= input("What is the new entry title: ") +'.txt'
	print(FileName)
	storeEncryptedMessages = open(FileName, "w") 
	message = input("Type: ") 
	print("-Pin must be a number-")
	shift = input("Enter pin for the entry: ") 
	enctpMessage = encrypt(message, shift) 
	storeEncryptedMessages.write(enctpMessage + ' \n') 
	storeEncryptedMessages.close() 
	print("The encrypted entry is:")
	print("  ")
	sleep(2)
	print(enctpMessage)
	print(" ")
	print("  ")
	print(" ")
	sleep(2)
	print("PLEASE REMEMBER THE PIN ")

def viewEntry():
	FileName= input("What is the entry you want to view: ") +'.txt'
	print(FileName)
	with open(FileName, 'r') as file:
		toview=file.read()
	message = toview 
	print("-Pin must be a number-")
	shift = input("Enter pin of the entry: ") 
	DecryptedMessage = decrypt(message, shift) 
	print(" ")
	sleep(2)
	print(DecryptedMessage)
	print(" ")
	sleep(2)
	print("-GO BACK TO MAIN MENU TO EDIT")
	print(" ")

def editEntry():
	FileName= input("What is the entry you want to edit: ") +'.txt'
	print(FileName)


	with open(FileName, 'r') as file:
		toedit=file.read()

	storeDecryptedMessages = open(FileName, "w") 
	message = toedit 
	print("-Pin must be a number-")
	shift = input("Enter pin of the entry: ") 
	DecryptedMessage = decrypt(message, shift) 
	storeDecryptedMessages.write(DecryptedMessage + '\n'+'\n') 
	storeDecryptedMessages.close() 
	print(" ")
	sleep(2)
	print(DecryptedMessage)
	sleep(2)
	print(" ")
	print("You could now edit your entry as a text document. Don't forget to save/encrypt later!")
	print(" ")
	print(" ")
	

def saveEntry():
	FileName= input("What is the entry title you want to encrypt/conceal: ") +'.txt'
	print(FileName)

	with open(FileName, 'r') as file:
		toedit=file.read()
	
	storeEncryptedMessages = open(FileName, "w") 
	message = toedit 
	print("-Pin must be a number-")
	shift = input("Enter pin of the entry:") 
	enctpMessage = encrypt(message, shift) 
	storeEncryptedMessages.write(enctpMessage + ' \n') 
	storeEncryptedMessages.close()
	print("The encrypted entry is")
	print(" ' ")
	print(enctpMessage)
	print(" ")
	print(" ' ")
	print(" ")
	print("PLEASE REMEMBER THE PIN ")



def instructions():
	print("====  INSTRUCTIONS =====")
	sleep(1.5)
	print("1.) To enter a new diary entry, select [1]. It is recommended to choose a pin from number 1-26.")
	print("2.) [1] ONLY views the entry. It decrypts your entry so it is readable if a correct pin was entered.")
	print("3.) To edit an entry, please select [3]. Upon entering the correct entry name and pin, it allows you to edit it via your text editor (like Notepad).")
	print("    Don't forget to save your entry after so it keeps the entry not readable (encrpyted).")
	print("4.) To keep your entry hidden and concealed, select 'Save Entry' and then enter the entry title and chosen pin.")
	print("5.) In changing password [3], it is advised to keep your password to a 4-digit pin .")




#opening the main program with 3 attempts
attempt=0
while True:
	with open("password.txt", 'r') as file:
		currentpass = file.readlines()[7]
	x = input("Enter Diary Password:") + '\n'
	attempt+=1
	if attempt==3:
		print("Too many attempts..")
		sleep(.5)
		print("INTRUDER ALERT!")
		quit()
	else:
		if x==currentpass:
			menu()
			break
		else:
			print("Invalid password")











