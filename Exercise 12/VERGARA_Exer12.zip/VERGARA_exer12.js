// JavaScript source code

//initialize variables
let forForm = document.forms["FORM"];

let SizeofPizza = new Array();
SizeofPizza["small"] = 125;
SizeofPizza["medium"] = 250;
SizeofPizza["large"] = 500;

let CrustofPizza = new Array();
CrustofPizza["thin"] = 50;
CrustofPizza["thick"] = 70;


let mainTopping = new Array();
mainTopping["pepperonioverload"] = 100;
mainTopping["hawaiian"] = 50;
mainTopping["meatoverload"] = 125;

//calculations
function getPizzaSizePrice() {
	var pizzaSizePrice = 0;


	let selectedSize = forForm.elements["size"]

	for (let i = 0; i < selectedSize.length; i++) {
		if (selectedSize[i].checked) {
			pizzaSizePrice = SizeofPizza[selectedSize[i].value];
			break;
		}
	}
	return pizzaSizePrice;
}
document.addEventListener('click', function (event) {
	document.getElementById('pizza-size').innerHTML = getPizzaSizePrice()
});

function getCrustPrice() {
	let pizzaCrustPrice = 0;

	let selectedCrust = forForm.elements["crust"]

	for (let i = 0; i < selectedCrust.length; i++) {
		if (selectedCrust[i].checked) {
			pizzaCrustPrice = CrustofPizza[selectedCrust[i].value];
			break;
		}
	}
	return pizzaCrustPrice;
}
document.addEventListener('click', function (event) {
	document.getElementById('crust-type').innerHTML = getCrustPrice()
});

function getMainToppingPrice() {
	let pizzaMainToppingPrice = 0

	let selectedMainTopping = forForm.elements["maintopping"]
	pizzaMainToppingPrice = mainTopping[selectedMainTopping.value];

	return pizzaMainToppingPrice
}
document.addEventListener('click', function (event) {
	document.getElementById('main-topping').innerHTML = getMainToppingPrice()
});

function getAdditionalToppingsPrice() {
	let vegetablePrice = 0;
	let meatPrice = 0;
	let cheesePrice = 0;


	let selectedVegetable = forForm.elements["vegetables"];
	let selectedMeat = forForm.elements["meat"];
	let selectedCheese = forForm.elements["cheese"];

	if (selectedVegetable.checked == true) vegetablePrice = 12;
	if (selectedMeat.checked == true) meatPrice = 75;
	if (selectedCheese.checked == true) cheesePrice = 50;

	totalAdditionalToppingPrice = vegetablePrice + meatPrice + cheesePrice

	return totalAdditionalToppingPrice;
}
document.addEventListener('click', function (event) {
	document.getElementById('additional-toppings').innerHTML = getAdditionalToppingsPrice()
});

function Total() {
	return getPizzaSizePrice() + getCrustPrice() + getMainToppingPrice() + getAdditionalToppingsPrice();	
}
document.addEventListener('click', function (event) {
	document.getElementById('total-no-tax').innerHTML = Total()
});

function TotalwTax() {
	var withTax = (Total() * .12) + Total();
	return withTax.toFixed(2);
}
document.addEventListener('click', function (event) {
	document.getElementById('total-w-tax').innerHTML = TotalwTax()
});


// for time
const deliveryTime = document.getElementById('deliverytime');
deliveryTime.addEventListener('change', function (event) {
	while (time.value > '10:00' || time.value < '19:00') {
		alert('Invalid delivery time. Please pick a time from 10AM-7PM.')
	};
});





